--SQL Advance Case Study


--Q1--BEGIN 
	
SELECT * 
FROM DIM_LOCATION DL INNER JOIN FACT_TRANSACTIONS FT ON DL.IDLocation=FT.IDLocation

--Q1--END

--Q2--BEGIN 
SELECT TOP 1 DL.STATE,COUNT(DC.IDCustomer) [CUSTOMER COUNT]
FROM [FACT_TRANSACTIONS] FT with(nolock)
INNER JOIN [DIM_MODEL] DM ON FT.IDModel=DM.IDModel
INNER JOIN [DIM_MANUFACTURER] DM2 ON DM.IDManufacturer=DM2.IDManufacturer
INNER JOIN [DIM_LOCATION] DL ON FT.IDLocation=DL.IDLocation
INNER JOIN [DIM_CUSTOMER] DC ON FT.IDCustomer=DC.IDCustomer
WHERE DM2.IDManufacturer=12 AND DL.Country='US'
GROUP BY DL.State
ORDER BY[CUSTOMER COUNT] DESC

--Q2--END

--Q3--BEGIN   
select dl.ZipCode,dl.[State],count(FT.IDMODEL)[COUNT_OF_TRANSACTION]
from FACT_TRANSACTIONS FT with(nolock)
INNER JOIN [DIM_MODEL] DM ON FT.IDModel=DM.IDModel
INNER JOIN [DIM_MANUFACTURER] DM2 ON DM.IDManufacturer=DM2.IDManufacturer
INNER JOIN [DIM_LOCATION] DL ON FT.IDLocation=DL.IDLocation
INNER JOIN [DIM_CUSTOMER] DC ON FT.IDCustomer=DC.IDCustomer
GROUP BY FT.IDModel,DL.ZipCode,DL.[State]



--Q4--BEGIN

SELECT TOP 1 MODEL_NAME ,(UNIT_PRICE)
FROM DIM_MODEL with(nolock)
ORDER BY Unit_price ASC
--Q4--END

--Q5--BEGIN
SELECT TOP 5 MANUFACTURER_NAME, MODEL_NAME,AVG(TOTALPRICE) AS 'AVEREGE TOTAL'
FROM [FACT_TRANSACTIONS] FT with(nolock)
INNER JOIN DIM_MODEL DM ON FT.IDModel=DM.IDModel
INNER JOIN DIM_MANUFACTURER DM2 ON DM.IDManufacturer=DM2.IDManufacturer
GROUP BY Model_Name,Manufacturer_Name
ORDER BY AVG(TotalPrice) DESC

--Q5--END

--Q6--BEGIN

SELECT Customer_Name, AVG(TOTALPRICE) AS 'TOTAL_AMOUNT'
FROM   [FACT_TRANSACTIONS] FT
 INNER JOIN [DIM_CUSTOMER] DC ON DC.IDCustomer= FT.IDCustomer
 WHERE YEAR([DATE])=2009
 GROUP BY Customer_Name
 HAVING AVG(TOTALPRICE)>500

--Q6--END
	
--Q7--BEGIN  
select * from 
(select top 5 ft.IDModel,Model_Name
from FACT_TRANSACTIONS ft WITH(nolock)
	INNER JOIN [DIM_MODEL] DM ON FT.IDModel=DM.IDModel
	INNER JOIN [DIM_MANUFACTURER] DM2 ON DM.IDManufacturer=DM2.IDManufacturer
where year([date]) = 2008 
group by ft.IDModel,Model_Name
order by  sum(Quantity)desc) as t1
intersect
select * from
(select top 5 ft.IDModel,Model_Name
from FACT_TRANSACTIONS ft
	INNER JOIN [DIM_MODEL] DM ON FT.IDModel=DM.IDModel
	INNER JOIN [DIM_MANUFACTURER] DM2 ON DM.IDManufacturer=DM2.IDManufacturer
where year([date]) = 2009
group by ft.IDModel,Model_Name
order by  sum(Quantity)desc) as t2
intersect
select * from
(select top 5  ft.IDModel,Model_Name
from FACT_TRANSACTIONS ft
	INNER JOIN [DIM_MODEL] DM ON FT.IDModel=DM.IDModel
	INNER JOIN [DIM_MANUFACTURER] DM2 ON DM.IDManufacturer=DM2.IDManufacturer
where year([date]) = 2010
group by ft.IDModel,Model_Name
order by  sum(Quantity)desc) as t3

--Q7--END	
--Q8--BEGIN

select * from 
(select Unit_price,dm2.Manufacturer_Name
from FACT_TRANSACTIONS ft
	 INNER JOIN [DIM_MODEL] DM ON FT.IDModel=DM.IDModel
	INNER JOIN [DIM_MANUFACTURER] DM2 ON DM.IDManufacturer=DM2.IDManufacturer
where year([date]) = 2009
order by Unit_price desc
offset 1 rows
fetch next 1 rows only) as t1
union
select * from
(select Unit_price,dm2.Manufacturer_Name
from FACT_TRANSACTIONS ft
	INNER JOIN [DIM_MODEL] DM ON FT.IDModel=DM.IDModel
	INNER JOIN [DIM_MANUFACTURER] DM2 ON DM.IDManufacturer=DM2.IDManufacturer
where year([date]) = 2010
order by Unit_price desc
offset 1 rows
fetch next 1 rows only) as t2

--Q8--END

--Q9--BEGIN
(select DM2.Manufacturer_Name
from FACT_TRANSACTIONS ft
	 INNER JOIN [DIM_MODEL] DM ON FT.IDModel=DM.IDModel
	 INNER JOIN [DIM_MANUFACTURER] DM2 ON DM.IDManufacturer=DM2.IDManufacturer
WHERE YEAR([DATE]) = 2010
GROUP BY Manufacturer_Name)
	 EXCEPT
(select DM2.Manufacturer_Name
from FACT_TRANSACTIONS ft
	 INNER JOIN [DIM_MODEL] DM ON FT.IDModel=DM.IDModel
	 INNER JOIN [DIM_MANUFACTURER] DM2 ON DM.IDManufacturer=DM2.IDManufacturer
WHERE YEAR([DATE]) = 2009
GROUP BY Manufacturer_Name)

--Q9--END

--Q10--BEGIN
	
SELECT TOP 100 IDCUSTOMER,YEAR([DATE]),AVG(TOTALPRICE), AVG(QUANTITY) , YEAR ([DATE])/AVG(TOTALPRICE) 
FROM FACT_TRANSACTIONS ft
GROUP BY YEAR([DATE]), IDCustomer
ORDER BY YEAR([DATE]),AVG(TOTALPRICE) DESC
	
--Q10--END
	